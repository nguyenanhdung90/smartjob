package com.smartJob.demo;

public class DefaultValue {

    public float outdoorTemperature;

    public static void main(String[] args) {
        System.out.println(String.valueOf((new DefaultValue()).outdoorTemperature));
    }

}