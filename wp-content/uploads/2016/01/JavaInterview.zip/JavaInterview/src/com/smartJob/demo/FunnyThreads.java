package com.smartJob.demo;

public class FunnyThreads {

    public static void main(String[] args) {
        Thread t = new SmartJobThread() {
            public void run() {
                System.out.println(" foo");
            }
        };
        t.start();
    }
}