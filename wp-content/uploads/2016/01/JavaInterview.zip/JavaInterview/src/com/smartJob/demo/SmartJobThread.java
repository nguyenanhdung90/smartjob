package com.smartJob.demo;

class SmartJobThread extends Thread {

    SmartJobThread() {
        System.out.print(" SmartJob");
    }

    public void run() {
        System.out.print(" bar");
    }

    public void run(String s) {
        System.out.println(" foo");
    }
}
