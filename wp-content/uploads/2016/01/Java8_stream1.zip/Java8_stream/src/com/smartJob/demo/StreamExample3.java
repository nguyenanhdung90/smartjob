package com.smartJob.demo;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamExample3 {

    public static void main(String[] args) {
        Employee e1 = new Employee("Nguyễn Vân Anh", 25, "Quản trị nguồn nhân lực");
        Employee e2 = new Employee("Phạm Văn Đoan", 32, "PHP");
        Employee e3 = new Employee("Nguyễn Văn Dũng", 23, "PHP");
        Employee e4 = new Employee("Nguyễn Văn Bắc", 24, "SEO");

        // Tạo danh sách (list) gồm 4 nhân viên đã khởi tạo ở trên.
        List<Employee> employeeList = Arrays.asList(e1, e2, e3, e4);
        // Tạo cấu trúc dữ liệu map.
        Map<Integer, Long> from24YearsOld = employeeList.stream().parallel()
                // Lọc ra các nhân viên từ 24 tuổi trở lên mới thêm vào map.
                .filter(
                        employee -> employee.getAge() >= 24
                )
                // Nhóm lại theo độ tuổi.
                .collect(
                        Collectors.groupingBy(Employee::getAge, Collectors.counting())
                );
        // Kích thước (số phần tử) của map, cũng là số nhân viên từ 24 tuổi trở lên.
        System.out.println("Số lượng nhân viên từ 24 tuổi trở lên là: " + from24YearsOld.size());
    }
}

/**
 * Thực thể "Nhân viên".
 */
class Employee {

    // Tên nhân viên.
    private String fullname;
    // Tuổi.
    private int age;
    // Kỹ năng/chuyên môn chính.
    private String mainSkill;

    public Employee() {
    }

    public Employee(String fullname, int age, String mainSkill) {
        this.fullname = fullname;
        this.age = age;
        this.mainSkill = mainSkill;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getMainSkill() {
        return mainSkill;
    }

    public void setMainSkill(String mainSkill) {
        this.mainSkill = mainSkill;
    }

}

// Kết quả:
//run:
//Số lượng nhân viên từ 24 tuổi trở lên là: 3
//BUILD SUCCESSFUL (total time: 0 seconds)
