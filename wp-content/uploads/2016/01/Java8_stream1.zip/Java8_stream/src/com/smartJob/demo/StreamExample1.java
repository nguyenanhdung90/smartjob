package com.smartJob.demo;

import java.util.stream.Stream;

public class StreamExample1 {

    public static void main(String[] args) {
        Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
                .parallel()
                .map(s -> s.toString())
                .map(s -> s + " ")
                .forEach(System.out::print);
    }

}

// Kết quả:

//run:
//7 6 9 10 8 3 5 4 2 1 BUILD SUCCESSFUL (total time: 0 seconds)