package com.smartJob.demo;

import java.util.stream.IntStream;

public class Counting {

    public static void main(String[] args) {
        // Có tổng số 13 ký tự.
        String foo = "smartjobdotvn";
        IntStream letters = foo.chars();
        long counter = letters.distinct().count();
        // Nhưng chỉ có 11 ký tự sau khi loại bỏ trùng lặp.
        System.out.println("Số ký tự có mặt trong chuỗi (đã loại bỏ trùng lặp): " + counter);
    }
    
}

// Kết quả:

//run:
//Số ký tự có mặt trong chuỗi (đã loại bỏ trùng lặp): 11
//BUILD SUCCESSFUL (total time: 0 seconds)