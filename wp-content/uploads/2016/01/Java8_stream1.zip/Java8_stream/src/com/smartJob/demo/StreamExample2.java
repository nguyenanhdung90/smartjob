package com.smartJob.demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StreamExample2 {

    public static void main(String[] args) {
        List<String> list = Arrays.asList("Hoàng Thế Anh", "Nguyễn Văn Còn", "Đoàn Minh Huệ", "Phạm Văn Đoan");

        list
                // Chuyển danh sách (list) thành dòng (stream).
                .stream()
                // Chuyển các ký tự về dạng viết hoa.
                .map(String::toUpperCase)
                // So sánh độ dài của các xâu (String). Tìm ra xâu có độ dài lớn nhất.
                .max(Comparator.comparing(String::length))
                // Nếu tồn tại xâu có độ dài lớn nhất (ifPresent: nếu có mặt/hiện diện), thì in ra.
                .ifPresent(System.out::println);
    }
    
}

// Kết quả:

//run:
//NGUYỄN VĂN CÒN
//BUILD SUCCESSFUL (total time: 0 seconds)