package com.smartJob.demo;

public class PassBy {

    private static void foo(String bar) {
        bar = "SmartJob";
    }

    public static void main(String[] args) {
        String baz = "Hello";
        foo(baz);
        System.out.println(baz);
    }

}