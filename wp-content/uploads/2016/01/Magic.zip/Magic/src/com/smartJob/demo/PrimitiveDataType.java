package com.smartJob.demo;

import java.util.Random;

public class PrimitiveDataType {

    public static void main(String[] args) {
        int i = (byte) +(char) -(int) +(long) - 1;
        System.out.println(i);
    }
}
