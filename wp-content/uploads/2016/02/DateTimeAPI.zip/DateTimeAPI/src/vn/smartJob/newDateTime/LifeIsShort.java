package vn.smartJob.newDateTime;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

public class LifeIsShort {

	public static void main(String[] args) {
		// Khởi tạo đối tượng Thời gian là hiện tại (Giờ địa phương).
		LocalDateTime now = LocalDateTime.now();
		System.out.println("[1] Giờ hiện tại: " + now);

		// Khởi tạo ngày địa phương từ ba giá trị: Năm + Tháng + Ngày.
		LocalDate today = LocalDate.of(2016, Month.FEBRUARY, 11);
		System.out.println("[2] Hôm nay là ngày: " + today);

		// Khởi tạo giờ địa phương từ xâu ký tự.
		LocalTime tenHourPM = LocalTime.parse("22:44:30");
		System.out.println("[3] Mười giờ 44 phút buổi tối: " + tenHourPM);

		// Khởi tạo giờ địa phương, từ Giờ + Phút. Ví dụ: 2 giờ 42 phút chiều.
		LocalTime twoHour42minsPM = LocalTime.of(14, 42);
		System.out.println("[4] Hai giờ 42 phút chiều: " + twoHour42minsPM);
		

		// Ngày được lấy làm mốc trong hệ thống máy tính là 01/01/1970.
		LocalDate mileStone = LocalDate.ofEpochDay(0);
		// Bích Vân sinh vào ngày thứ 6483 tính từ mốc thời gian 1/1/1970.
		LocalDate bichVanDateOfBirth = LocalDate.ofEpochDay(6483);
		System.out.println("[5] Bích Vân sinh vào ngày thứ 6483 tính từ mốc thời gian " + 
		mileStone + ", tức là ngày " + bichVanDateOfBirth);
		

		// VyDN sinh ngày 26/08/1987 (Ngày địa phương).
		LocalDate vyDate = LocalDate.of(1987, Month.AUGUST, 26);
		// 1 giờ 15 phút chiều (Giờ địa phương).
		LocalTime vyTime = LocalTime.of(13, 15);
		// Tạo múi giờ dựa trên offset. Hà Nội ở múi giờ GMT+7.
		ZoneId HaNoi = ZoneOffset.of("+07:00");
		// Tạo đối tượng thời gian có gắn kèm múi giờ.
		ZonedDateTime VyDN_DateOfBirth = ZonedDateTime.of(vyDate, vyTime, HaNoi);
		System.out.println("[6] Ngày sinh VyDN giờ địa phương: " + VyDN_DateOfBirth);
		// ZoneId.of("Z") là múi giờ UTC/Greenwich.
		ZonedDateTime VyDN_DateOfBirth_UTC = VyDN_DateOfBirth.withZoneSameInstant(ZoneId.of("Z"));
		System.out.println("[7] Ngày sinh VyDN tính theo giờ UTC/Greenwich: " + VyDN_DateOfBirth_UTC);
		

		// Tính khoảng cách giữa hai điểm thời gian.
		long vyDN_BichVan_Offset = Duration
				.between(VyDN_DateOfBirth, ZonedDateTime.of(bichVanDateOfBirth, LocalTime.of(0, 0), HaNoi)).toDays();
		System.out.println("[8] Hai người sinh cách nhau " + String.valueOf(vyDN_BichVan_Offset) + " ngày.");
	}
}

// Kết quả:
// [1] Giờ hiện tại: 2016-02-12T00:06:23.763
// [2] Hôm nay là ngày: 2016-02-11
// [3] Mười giờ 44 phút buổi tối: 22:44:30
// [4] Hai giờ 42 phút chiều: 14:42
// [5] Bích Vân sinh vào ngày thứ 6483 tính từ mốc thời gian 1970-01-01, tức là ngày 1987-10-02
// [6] Ngày sinh VyDN giờ địa phương: 1987-08-26T13:15+07:00
// [7] Ngày sinh VyDN tính theo giờ UTC/Greenwich: 1987-08-26T06:15Z
// [8] Hai người sinh cách nhau 36 ngày.