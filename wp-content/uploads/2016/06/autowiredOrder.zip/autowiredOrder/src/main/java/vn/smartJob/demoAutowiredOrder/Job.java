package vn.smartJob.demoAutowiredOrder;

public abstract class Job {

}
