// require module http
var http = require("http");// require module file system
var fs = require("fs");
var port = 80, host = '127.0.0.1';// create server
var server = http.createServer(function (request, response) {
// get file request
    var urlRequest = request.url;
    console.log("Received request: " + urlRequest);

// file path
    var filePath = "./public" + urlRequest;

// read file
    fs.readFile(filePath, function (error, data) {

// has error
        if (error) {

            response.writeHead(400, {"Content-type": "text/plain ;charset=utf-8"});
            response.end("Sorry, The page not found");
        }

// response data for client
        else {

            response.writeHead(200, {"Content-type": "text/html;charset=utf-8"});
            //
			//;
			response.write(data);
            response.end();
			console.log(data);
        }

    });

});

// open port and listen client
server.listen(port, host, function () {

    var address = server.address();
    console.log("opened server on %j", address);
});