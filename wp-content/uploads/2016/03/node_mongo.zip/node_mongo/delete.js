var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

// Connection URL. This is where your mongodb server is running.
var url = 'mongodb://localhost:27017/test';

// Use connect method to connect to the Server
MongoClient.connect(url, function (err, db) {
    if (err) {
        console.log('Unable to connect to the mongoDB server. Error:', err);
    } 
	else 
	{
	console.log('Connection established to', url);

	// Get the documents collection
	var collection = db.collection('zips');
	// start 
	collection.deleteOne({ city : 'smartjob.vn2' }, function(err, result) {
      if (err) {
        console.log(err);
      } else {
        console.log('xoa thanh cong');
      }
      //Close connection
      db.close();
	});	
	//end	
    }
});