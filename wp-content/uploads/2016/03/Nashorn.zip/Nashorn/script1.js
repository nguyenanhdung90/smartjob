var displayInfo = function(info) {
	print('Nội dung này được gọi ra bởi JavaScript, nói rằng: ' + info);
	return "Tê giác sắp bị tuyệt chủng";
};

var getTypeOfObject = function(object) {
	print("Kiểu đối tượng là: " + Object.prototype.toString.call(object));
};
