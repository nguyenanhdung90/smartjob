package example.android.trinh.lap.customlistview.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import example.android.trinh.lap.customlistview.R;
import example.android.trinh.lap.customlistview.adapters.MovieAdapter;
import example.android.trinh.lap.customlistview.entities.Movie;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private ArrayList<Movie> mMovieList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        setDataListView();
    }

    private void initView() {
        mListView = (ListView) findViewById(R.id.listview);
    }

    private void initData() {
        mMovieList = new ArrayList<>();
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://www.musicmusic.vn/FileClip/Photos/Hoquanghieu-conbuomxuan.jpg", 1245, 1034, 20));
        mMovieList.add(new Movie("Chắc ai đó sẽ về", "Sơn Tùng M - TP", "https://i.ytimg.com/vi/H-fI_h_pXw8/maxresdefault.jpg", 1234, 1050, 35));
        mMovieList.add(new Movie("Con gái có quyền điệu", "Hari Won", "https://i.ytimg.com/vi/6IhL_-PuDxw/maxresdefault.jpg", 12454, 1040, 23));
        mMovieList.add(new Movie("Âm thầm bên em", "Sơn Tùng M - TP", "http://media.doisongphapluat.com/423/2015/8/22/sontung01.PNG", 1245, 105, 56));
        mMovieList.add(new Movie("Tìm em", "Hồ Quang Hiếu", "http://image.mp3.zdn.vn/thumb_video/e/9/e907aad8342bfdf25d1a1be89a94aa67_1393816732.jpg", 1245, 1000, 0));
        mMovieList.add(new Movie("Buông đôi tay nhau ra", "Sơn Tùng M - TP", "http://xmedia-nguoiduatin.cdn.vccloud.vn/thumb_x500x/2015/12/3/235/buong-doi-tay-nhau-ra-son-tung-4-1449109597.jpg", 3556, 156, 53));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1745, 1050, 54));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 175, 1000, 65));
        mMovieList.add(new Movie("Con Bướm Xuân", "Sơn Tùng M - TP", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 455, 1000, 6));
        mMovieList.add(new Movie("Ngã Tư Đường", "Hồ Quang Hiếu", "http://imgs.vietnamnet.vn/Images/2012/05/04/17/20120504170346_7.jpg", 15745, 1030, 0));
        mMovieList.add(new Movie("Hết yêu", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 12745, 1045, 23));
        mMovieList.add(new Movie("Không phải dạng vừa đâu", "Sơn Tùng M - TP", "https://i.ytimg.com/vi/gJkkPK0aXFo/maxresdefault.jpg", 75, 100, 0));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 125, 1000, 89));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1677, 109, 78));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1245, 60, 89));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1245, 103, 34));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1245, 1005, 90));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1245, 106, 34));
        mMovieList.add(new Movie("Con Bướm Xuân", "Hồ Quang Hiếu", "http://img.saobiz.net/d/2015/07/nhung-hinh-anh-dep-cua-ca-si-Ho-Quang-Hieu.jpg", 1245, 106, 90));

    }

    private void setDataListView() {
        MovieAdapter movieAdapter = new MovieAdapter(this, mMovieList);
        mListView.setAdapter(movieAdapter);
    }
}
