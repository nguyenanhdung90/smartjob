package example.android.trinh.lap.customlistview.entities;

/**
 * Created by thuynguyen on 1/26/16.
 */
public class Movie {
    private String mName;
    private String mAuthor;
    private String mUrlImage;
    private int mCountView;
    private int mCountLike;
    private int mCountDisLike;
    public Movie() {}
    public Movie(String name, String author, String urlImage, int countView, int countLike, int countDisLike) {
        this.mName = name;
        this.mAuthor = author;
        this.mUrlImage = urlImage;
        this.mCountView = countView;
        this.mCountLike = countLike;
        this.mCountDisLike = countDisLike;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public void setmAuthor(String mAuthor) {
        this.mAuthor = mAuthor;
    }

    public String getmUrlImage() {
        return mUrlImage;
    }

    public void setmUrlImage(String mUrlImage) {
        this.mUrlImage = mUrlImage;
    }

    public int getmCountView() {
        return mCountView;
    }

    public void setmCountView(int mCountView) {
        this.mCountView = mCountView;
    }

    public int getmCountLike() {
        return mCountLike;
    }

    public void setmCountLike(int mCountLike) {
        this.mCountLike = mCountLike;
    }

    public int getmCountDisLike() {
        return mCountDisLike;
    }

    public void setmCountDisLike(int mCountDisLike) {
        this.mCountDisLike = mCountDisLike;
    }
}
