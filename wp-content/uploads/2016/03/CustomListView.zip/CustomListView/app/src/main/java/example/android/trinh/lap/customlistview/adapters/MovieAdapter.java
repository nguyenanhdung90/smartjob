package example.android.trinh.lap.customlistview.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import example.android.trinh.lap.customlistview.R;
import example.android.trinh.lap.customlistview.entities.Movie;

/**
 * Created by thuynguyen on 1/26/16.
 */
public class MovieAdapter extends BaseAdapter {
    private ArrayList<Movie> mMovieList;
    private LayoutInflater mLayoutInflater;
    private Context mContext;

    public MovieAdapter(Context context, ArrayList<Movie> movies) {
        this.mContext = context;
        this.mMovieList = movies;
        this.mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mMovieList != null ? mMovieList.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return mMovieList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.item_listview, null);
            holder.mImage = (ImageView) convertView.findViewById(R.id.img_illustration);
            holder.mTitle = (TextView) convertView.findViewById(R.id.txt_title_event);
            holder.mAuthor = (TextView) convertView.findViewById(R.id.txt_author);
            holder.mCountView = (TextView) convertView.findViewById(R.id.txt_count_view);
            holder.mCountLike = (TextView) convertView.findViewById(R.id.txt_count_like);
            holder.mCountDisLike = (TextView) convertView.findViewById(R.id.txt_count_dislike);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Movie event = (Movie) getItem(position);
        Picasso.with(mContext).load(event.getmUrlImage()).into(holder.mImage);
        holder.mAuthor.setText(event.getmAuthor());
        holder.mTitle.setText(event.getmName());
        holder.mCountView.setText(String.valueOf(event.getmCountView()));
        holder.mCountLike.setText(String.valueOf(event.getmCountLike()));
        holder.mCountDisLike.setText(String.valueOf(event.getmCountDisLike()));
        return convertView;
    }

    public class ViewHolder {
        private ImageView mImage;
        private TextView mTitle;
        private TextView mAuthor;
        private TextView mCountView;
        private TextView mCountLike;
        private TextView mCountDisLike;
    }
}

